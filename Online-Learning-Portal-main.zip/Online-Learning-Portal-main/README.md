# LearnHub - Online Learning Portal

## Project Overview

LearnHub is an Online Learning Portal developed using Flask and SQLite. 
The platform allows students to register, login, explore courses, enroll, and track their learning progress.

The application is containerized using Docker for cloud deployment.


## Features

- User Registration and Login
- Secure Password Encryption
- Course Listing
- Course Enrollment
- Student Dashboard
- Learning Progress Tracking
- Admin Course Management
- Add and Delete Courses


## Technology Stack

### Frontend
- HTML5
- CSS3
- JavaScript

### Backend
- Python
- Flask

### Database
- SQLite

### Cloud Computing
- Docker
- Docker Compose


## Project Structure
