from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash
)

import sqlite3

from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)


# ==========================
# Flask Configuration
# ==========================

app = Flask(__name__)

app.secret_key = "learnhub_secret_key_2026"


DATABASE = "database.db"



# ==========================
# Database Connection
# ==========================

def get_db():

    conn = sqlite3.connect(DATABASE)

    conn.row_factory = sqlite3.Row

    return conn



# ==========================
# Create Database Tables
# ==========================

def init_db():

    conn = get_db()

    cursor = conn.cursor()


    # Users Table

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        name TEXT NOT NULL,

        email TEXT UNIQUE NOT NULL,

        password TEXT NOT NULL,

        role TEXT DEFAULT 'student'

    )
    """)



    # Courses Table

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS courses(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        course_name TEXT NOT NULL,

        instructor TEXT NOT NULL,

        duration TEXT NOT NULL,

        level TEXT NOT NULL,

        description TEXT NOT NULL

    )
    """)



    # Enrollments Table

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS enrollments(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        course_id INTEGER,

        progress INTEGER DEFAULT 0,

        completed INTEGER DEFAULT 0,


        FOREIGN KEY(user_id)
        REFERENCES users(id),


        FOREIGN KEY(course_id)
        REFERENCES courses(id)

    )
    """)



    conn.commit()



    # Add default courses

    cursor.execute(
        "SELECT COUNT(*) FROM courses"
    )

    count = cursor.fetchone()[0]


    if count == 0:


        default_courses = [

(
"Python Programming",
"John Smith",
"8 Weeks",
"Beginner",
"Learn Python programming from basics to advanced concepts with real-world projects."
),


(
"Cloud Computing",
"David Williams",
"10 Weeks",
"Intermediate",
"Learn AWS, Azure, Docker, virtualization and cloud deployment concepts."
),


(
"Artificial Intelligence",
"Dr. Sarah Lee",
"12 Weeks",
"Advanced",
"Learn AI, machine learning models, deep learning and intelligent systems."
),


(
"Machine Learning",
"Michael Brown",
"10 Weeks",
"Intermediate",
"Build machine learning models using Python, NumPy, Pandas and Scikit-learn."
),


(
"Data Science",
"Emma Wilson",
"12 Weeks",
"Advanced",
"Learn data analysis, visualization, statistics and predictive modelling."
),


(
"Web Development",
"Robert Taylor",
"8 Weeks",
"Beginner",
"Learn HTML, CSS, JavaScript and build modern responsive websites."
),


(
"Cyber Security",
"Daniel Anderson",
"14 Weeks",
"Advanced",
"Understand network security, ethical hacking and cyber protection."
),


(
"Generative AI",
"Sophia Martin",
"10 Weeks",
"Advanced",
"Explore LLMs, prompt engineering and AI application development."
),


(
"DevOps Engineering",
"James Wilson",
"12 Weeks",
"Intermediate",
"Learn CI/CD, Docker, Git, automation and cloud deployment."
)

]
        


        cursor.executemany("""

        INSERT INTO courses(

            course_name,
            instructor,
            duration,
            level,
            description

        )

        VALUES(?,?,?,?,?)

        """, default_courses)


        conn.commit()



    conn.close()



# Initialize database

init_db()
# ==========================
# Home Page
# ==========================

@app.route("/")
def home():

    return render_template("index.html")



# ==========================
# Register
# ==========================

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form["name"]

        email = request.form["email"]

        password = request.form["password"]


        hashed_password = generate_password_hash(password)


        conn = get_db()

        cursor = conn.cursor()


        try:

            cursor.execute("""

            INSERT INTO users(

                name,
                email,
                password

            )

            VALUES(?,?,?)

            """,
            (
                name,
                email,
                hashed_password
            ))


            conn.commit()


            flash("Registration successful! Please login.")

            return redirect("/login")


        except sqlite3.IntegrityError:


            flash("Email already registered.")

            return redirect("/register")


        finally:

            conn.close()



    return render_template("register.html")



# ==========================
# Login
# ==========================

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]

        password = request.form["password"]


        conn = get_db()

        cursor = conn.cursor()


        cursor.execute("""

        SELECT *

        FROM users

        WHERE email=?

        """,
        (email,))


        user = cursor.fetchone()


        conn.close()



        if user and check_password_hash(
            user["password"],
            password
        ):


            session["user_id"] = user["id"]

            session["user"] = user["name"]

            session["role"] = user["role"]



            flash("Login successful!")


            return redirect("/dashboard")



        else:


            flash("Invalid email or password.")


            return redirect("/login")



    return render_template("login.html")



# ==========================
# Logout
# ==========================

@app.route("/logout")
def logout():


    session.clear()


    flash("You have been logged out.")


    return redirect("/")



# ==========================
# Courses Page
# ==========================

@app.route("/courses")
def courses():


    conn = get_db()

    cursor = conn.cursor()


    cursor.execute("""

    SELECT *

    FROM courses

    ORDER BY id DESC

    """)


    courses = cursor.fetchall()


    conn.close()



    return render_template(

        "courses.html",

        courses=courses

    )



# ==========================
# Course Details
# ==========================

@app.route("/course/<int:course_id>")
def course_details(course_id):


    conn = get_db()

    cursor = conn.cursor()



    cursor.execute("""

    SELECT *

    FROM courses

    WHERE id=?

    """,
    (course_id,))


    course = cursor.fetchone()


    conn.close()



    if course is None:


        flash("Course not found.")

        return redirect("/courses")



    return render_template(

        "course_details.html",

        course=course

    )



# ==========================
# Enroll Course
# ==========================

@app.route("/enroll/<int:course_id>")
def enroll(course_id):


    if "user_id" not in session:


        flash("Please login to enroll.")

        return redirect("/login")



    conn = get_db()

    cursor = conn.cursor()



    user_id = session["user_id"]



    cursor.execute("""

    SELECT *

    FROM enrollments

    WHERE user_id=?

    AND course_id=?

    """,
    (
        user_id,
        course_id
    ))



    existing = cursor.fetchone()



    if existing:


        flash("Already enrolled in this course.")



    else:


        cursor.execute("""

        INSERT INTO enrollments(

            user_id,

            course_id,

            progress,

            completed

        )

        VALUES(?,?,0,0)

        """,
        (
            user_id,
            course_id
        ))



        conn.commit()


        flash("Course enrolled successfully!")



    conn.close()



    return redirect("/dashboard")
    # ==========================
# Student Dashboard
# ==========================

@app.route("/dashboard")
def dashboard():


    if "user_id" not in session:

        flash("Please login first.")

        return redirect("/login")



    conn = get_db()

    cursor = conn.cursor()



    user_id = session["user_id"]



    # Total enrolled courses

    cursor.execute("""

    SELECT COUNT(*)

    FROM enrollments

    WHERE user_id=?

    """,
    (user_id,))


    total_courses = cursor.fetchone()[0]



    # Completed certificates

    cursor.execute("""

    SELECT COUNT(*)

    FROM enrollments

    WHERE user_id=?

    AND completed=1

    """,
    (user_id,))


    certificates = cursor.fetchone()[0]



    # Average progress

    cursor.execute("""

    SELECT AVG(progress)

    FROM enrollments

    WHERE user_id=?

    """,
    (user_id,))


    avg_progress = cursor.fetchone()[0]


    if avg_progress is None:

        avg_progress = 0



    progress = int(avg_progress)



    # Learning hours calculation

    learning_hours = progress // 5



    # Enrolled courses

    cursor.execute("""

    SELECT

        courses.id,

        courses.course_name,

        courses.instructor,

        courses.duration,

        courses.level,

        enrollments.progress,

        enrollments.completed


    FROM enrollments


    JOIN courses


    ON courses.id = enrollments.course_id


    WHERE enrollments.user_id=?


    """,
    (user_id,))


    enrolled_courses = cursor.fetchall()



    conn.close()



    return render_template(

        "dashboard.html",

        username=session["user"],

        total_courses=total_courses,

        certificates=certificates,

        progress=progress,

        learning_hours=learning_hours,

        enrolled_courses=enrolled_courses

    )



# ==========================
# Admin Dashboard
# ==========================

@app.route("/admin")
def admin():


    if "user_id" not in session:

        flash("Login required.")

        return redirect("/login")



    conn = get_db()

    cursor = conn.cursor()



    cursor.execute("""

    SELECT COUNT(*)

    FROM users

    """)


    total_students = cursor.fetchone()[0]



    cursor.execute("""

    SELECT COUNT(*)

    FROM courses

    """)


    total_courses = cursor.fetchone()[0]



    cursor.execute("""

    SELECT COUNT(*)

    FROM enrollments

    """)


    total_enrollments = cursor.fetchone()[0]



    cursor.execute("""

    SELECT *

    FROM courses

    ORDER BY id DESC

    """)


    courses = cursor.fetchall()



    conn.close()



    return render_template(

        "admin.html",

        total_students=total_students,

        total_courses=total_courses,

        total_enrollments=total_enrollments,

        courses=courses

    )



# ==========================
# Add Course
# ==========================

@app.route("/add_course", methods=["GET","POST"])
def add_course():


    if request.method == "POST":


        course_name = request.form["course_name"]

        instructor = request.form["instructor"]

        duration = request.form["duration"]

        level = request.form["level"]

        description = request.form["description"]



        conn = get_db()

        cursor = conn.cursor()



        cursor.execute("""

        INSERT INTO courses(

            course_name,

            instructor,

            duration,

            level,

            description

        )

        VALUES(?,?,?,?,?)

        """,
        (

            course_name,

            instructor,

            duration,

            level,

            description

        ))



        conn.commit()

        conn.close()



        flash("Course added successfully!")


        return redirect("/admin")



    return render_template("add_course.html")



# ==========================
# Delete Course
# ==========================

@app.route("/delete_course/<int:course_id>")
def delete_course(course_id):


    conn = get_db()

    cursor = conn.cursor()



    # Delete related enrollments first

    cursor.execute("""

    DELETE FROM enrollments

    WHERE course_id=?

    """,
    (course_id,))



    # Delete course

    cursor.execute("""

    DELETE FROM courses

    WHERE id=?

    """,
    (course_id,))



    conn.commit()

    conn.close()



    flash("Course deleted successfully!")



    return redirect("/admin")



# ==========================
# Application Run
# ==========================

if __name__ == "__main__":


    app.run(

        host="0.0.0.0",

        port=5000,

        debug=True

    )